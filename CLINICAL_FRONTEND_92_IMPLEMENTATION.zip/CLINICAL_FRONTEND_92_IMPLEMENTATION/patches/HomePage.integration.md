# 기존 HomePage 통합

기존 `src/pages/HomePage.tsx`는 이미 `Routes`/`Route`를 사용한다.

추가 import:

```tsx
import ClinicalFrontendRoot from '../clinical/ClinicalFrontendRoot';
```

기존 `<Routes>` 안에 한 줄 추가:

```tsx
<Route path="/clinical/*" element={<ClinicalFrontendRoot />} />
```

`src/index.tsx`와 `App_socket_videosync.tsx`는 수정하지 않는다.
따라서 기존 `ExcalidrawWrapper`가 계속 최상위 Provider이고 Clinical 화면에서도
`useCollaboration()`으로 기존 mediasoup/Socket.IO 연결을 재사용한다.
