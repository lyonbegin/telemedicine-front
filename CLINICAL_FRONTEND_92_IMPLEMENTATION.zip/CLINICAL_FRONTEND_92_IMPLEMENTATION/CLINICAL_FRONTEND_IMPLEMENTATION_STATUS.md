# Clinical Frontend Implementation Status

- 총 화면: **92**
- 공통 4 / 환자 26 / 현장 의료인력 22 / 원격 의료인 20 / 운영·관리 20
- Backend route registry: **238**
- Backend 기준: **Schema 18**
- Static/TypeScript/installer audit: **PASS 15/15**

## 구현 완료

- `/clinical/*` role-based routing
- 보고서 우선 92화면 registry
- 환자 / 현장 의료인력 / 원격 의료인 / 운영·관리 Shell
- JWT Role claim 해석 + Production dev-role fallback 차단
- Backend API facade
- Backend 238 route registry
- 화면별 API mapping
- 기존 `useCollaboration()` 기반 RTC bridge
- ECG / DICOM / Ultrasound / Auscultation / Lab Viewer
- 동의 / 예약 / precheck / follow-up / dashboard 주요 화면 실제 API 연결
- 다음/이전 진료 Flow navigation
- generic clinical status PATCH 없음
- Read API가 없는 화면은 임의 임상 성공 데이터를 만들지 않음

## 검증 상태

PASS:
- 92 screen inventory
- 238 Backend route inventory
- screen API mapping
- facade route shape
- TypeScript overlay compile
- installer dry-run/apply/idempotency
- 기존 index/RTC source preservation fixture
- secret static scan

NOT_RUN:
- 사용자의 실제 `/home/dgmjs/apps/demo` working tree에서 `npm run build`
- 실제 Backend/DB E2E
- 실제 mediasoup/TURN 2-client E2E
