# 기존 Frontend 통합 기준

현재 프로젝트의 최상위 진입점은 `src/index.tsx`에서 기존 `ExcalidrawWrapper`
안에 앱을 렌더링하는 구조다. 이 파일은 Clinical 통합에서 수정하지 않는다.

현재 `src/pages/HomePage.tsx`는 React Router의 `<Routes>` / `<Route>`를 사용한다.
Clinical Frontend는 이 라우터에 아래 한 줄만 추가한다.

```tsx
<Route path="/clinical/*" element={<ClinicalFrontendRoot />} />
```

실시간 진료는 새 Socket.IO/mediasoup 클라이언트를 만들지 않는다.
`src/App_socket_videosync.tsx`가 제공하는 `useCollaboration()`을
`src/clinical/rtc/ExistingRtcBridge.tsx`가 재사용한다.

따라서:
- 기존 채팅/화이트보드/기타 화면 유지
- 기존 WebRTC/mediasoup Provider 유지
- Clinical UI는 별도 `/clinical/*` namespace
- Clinical Source of Truth는 Backend/DB
