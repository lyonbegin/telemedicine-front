# Clinical Frontend 92 Implementation

기존 Vite/React 프론트에 **추가형(additive)** 으로 설치하는 92화면 구현이다.

- 화면: **92**
- Backend route registry: **238**
- Backend 기준: Schema 18
- 기존 `index.tsx` / `ExcalidrawWrapper` 유지
- 기존 `App_socket_videosync.tsx`의 mediasoup + Socket.IO Context 재사용
- 진료 상태를 Frontend에서 generic PATCH 하지 않음
- 보고서에 있는 절차/문구/역할을 우선하고 보고서에 없는 현장검사/Device/Edge만 확장

## 기존 소스 적용

Dry run:

```bash
node scripts/install-into-existing-frontend.mjs /home/dgmjs/apps/demo
```

실제 적용:

```bash
node scripts/install-into-existing-frontend.mjs /home/dgmjs/apps/demo --apply
```

설치 후:

```bash
cd /home/dgmjs/apps/demo
npm run build
```

진입:

```text
/clinical/common/g01
/clinical/patient/p01
/clinical/site/s01
/clinical/clinician/c01
/clinical/operations/o01
```

## 중요한 운영 원칙

Production에서 `VITE_CLINICAL_DEV_ROLE`을 사용하지 않는다.
실제 Role/Permission/Scope는 Backend 인증에서 받은 값으로 세션에 넣는다.
외부 Provider나 의료기기 연결이 없는데 프론트에서 성공 상태를 만들어내지 않는다.
