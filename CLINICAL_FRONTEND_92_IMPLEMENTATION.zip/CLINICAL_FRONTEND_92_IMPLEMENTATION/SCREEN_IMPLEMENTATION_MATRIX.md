# 92 Screen Implementation Matrix

|화면|사용자|구현|Backend 연결|근거|
|---|---|---|---|---|
|G01 로그인|공통|LoginScreen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 주체별 역할·본인확인|
|G02 업무 선택|공통|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 주체별 역할|
|G03 접근성 설정|공통|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서 표 35: 접근성|
|G04 연결 상태 안내|공통|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술 및 품질|
|P01 비대면진료 이용 시작|환자|PatientHomeScreen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 예약·환자 자율성|
|P02 진료 요청 방법|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 비대면진료 요청/예약|
|P03 의료기관·시간 선택|환자|AppointmentScreen|`GET /clinical/patients/:patientUserId/appointment-slots`<br>`POST /clinical/appointments`|보고서: 중립적 예약 정보|
|P04 예약 전 안내|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 예약 전 안내|
|P05 보호자·대리인 확인|환자|ReportFirst Generic Screen|`GET /clinical/patients/:patientUserId/support-relations`<br>`POST /clinical/patients/:patientUserId/support-relations`|보고서 표 35: 보호자 지원|
|P06 본인확인|환자|ReportFirst Generic Screen|`POST /clinical/encounters/:id/identity/start`|보고서: 본인확인|
|P07 비대면진료 설명 및 동의|환자|ConsentScreen|`GET /clinical/encounters/:id/consents`<br>`POST /clinical/encounters/:id/consents`|보고서: 설명 및 동의|
|P08 건강정보 연동|환자|ReportFirst Generic Screen|`POST /clinical/patients/:patientUserId/health-information/sync`<br>`GET /clinical/patients/:patientUserId/health-information/snapshots`|보고서 표 35: 자동연동|
|P09 사전 문진|환자|ReportFirst Generic Screen|`POST /clinical/encounters/:id/intake`<br>`POST /clinical/encounters/:id/intake/:submissionId/answers`<br>`POST /clinical/encounters/:id/intake/:submissionId/submit`|보고서 표 33: 공통 문진|
|P10 추가 문진|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서 표 34: 선택 문진|
|P11 입력 확인|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서 표 35: 자동검증|
|P12 진료 전 확인 결과|환자|ReportFirst Generic Screen|`GET /clinical/encounters/:id/red-flags`|보고서 표 35: 위험신호|
|P13 진료 환경 점검|환자|PrecheckScreen|`POST /clinical/visits/:id/self-precheck`|보고서: 기술 및 품질|
|P14 진료 대기|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 진료 방식·시간|
|P15 비대면진료|환자|LiveVisitScreen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 비대면진료|
|P16 검사 진행 안내|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 진료 프로세스|
|P17 진료 결과 안내|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 진료 후 연속성|
|P18 처방 확인|환자|ReportFirst Generic Screen|`GET /clinical/patients/:patientUserId/prescriptions`|보고서: 처방|
|P19 처방전·약국|환자|ReportFirst Generic Screen|`GET /clinical/patients/:patientUserId/pharmacies`<br>`POST /clinical/prescriptions/:id/pharmacy-selection`|보고서: 약국·처방전|
|P20 진료 요약|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 후속관리|
|P21 사후관리 계획|환자|ReportFirst Generic Screen|`GET /clinical/patients/:patientUserId/follow-up/current`|보고서 표 36: T0|
|P22 경과 확인|환자|ReportFirst Generic Screen|`POST /clinical/follow-up-plans/:id/check-ins`|보고서 표 36: T1|
|P23 자가측정 기록|환자|ReportFirst Generic Screen|`POST /clinical/follow-up-plans/:id/measurements`|보고서 표 36: T2|
|P24 이상반응·증상 악화|환자|ReportFirst Generic Screen|`POST /clinical/follow-up-plans/:id/adverse-events`|보고서 표 36: T3|
|P25 대면·응급 전환|환자|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서 표 36: T4|
|P26 진료 기록·재진|환자|ReportFirst Generic Screen|`GET /clinical/patients/:patientUserId/history`<br>`GET /clinical/patients/:patientUserId/reports`<br>`GET /clinical/patients/:patientUserId/prescriptions`|보고서 표 36: T5|
|S01 현장 진료 대시보드|현장 의료인력|SiteDashboardScreen|`GET /clinical/dashboards/sites/:siteId`|보고서: 기술·품질/의료인 보조|
|S02 환자 대기 목록|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S03 환자 접수|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S04 본인확인 지원|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S05 보호자·대리인 확인|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S06 동의·문진 지원|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S07 기초 측정|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S08 위험 신호 확인|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S09 진료 사전 점검|현장 의료인력|PrecheckScreen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S10 현장 진료 화면|현장 의료인력|LiveVisitScreen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S11 검사오더|현장 의료인력|ReportFirst Generic Screen|`GET /clinical/dashboards/sites/:siteId/exam-orders`|보고서: 기술·품질/의료인 보조|
|S12 검사 준비도 확인|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S13 검사 담당자 배정|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S14 사용 장비 선택|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S15 검사 수행|현장 의료인력|ReportFirst Generic Screen|`POST /clinical/acquisitions/:id/start`<br>`POST /clinical/acquisitions/:id/stop`|보고서: 기술·품질/의료인 보조|
|S16 전송·오프라인 큐|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S17 데이터 수신·무결성|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S18 기술 품질 확인|현장 의료인력|ReportFirst Generic Screen|`POST /clinical/acquisitions/:id/quality-review`|보고서: 기술·품질/의료인 보조|
|S19 재검 요청|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S20 검체·POC 검사|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S21 장비·Edge 상태|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|S22 검사 종료·전달|현장 의료인력|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 기술·품질/의료인 보조|
|C01 의료진 대시보드|원격 의료인|ClinicianDashboardScreen|`GET /clinical/dashboards/specialists/:workforceId`|보고서: 의료인 역할·진료·처방·사후관리|
|C02 진료 대기 목록|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C03 환자 임상 요약|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C04 비대면진료 적합성 검토|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C05 원격진료 워크스페이스|원격 의료인|LiveVisitScreen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C06 검사오더 작성|원격 의료인|ReportFirst Generic Screen|`POST /clinical/exam-orders`<br>`POST /clinical/exam-orders/:id/submit`|보고서: 의료인 역할·진료·처방·사후관리|
|C07 검사 진행 모니터|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C08 ECG Viewer|원격 의료인|ECG Viewer|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C09 DICOM Viewer|원격 의료인|DICOM Viewer|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C10 초음파·영상 Viewer|원격 의료인|Ultrasound Viewer|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C11 청진 Viewer|원격 의료인|Auscultation Viewer|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C12 검사수치 Viewer|원격 의료인|Lab Viewer|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C13 기술 품질·재검 상태|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C14 전문의 판독|원격 의료인|ReportFirst Generic Screen|`POST /clinical/interpretations`|보고서: 의료인 역할·진료·처방·사후관리|
|C15 진단 보고서|원격 의료인|ReportFirst Generic Screen|`POST /clinical/diagnostic-reports`<br>`POST /clinical/diagnostic-reports/:id/sign`|보고서: 의료인 역할·진료·처방·사후관리|
|C16 중요 결과 전달|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C17 처방 작성|원격 의료인|ReportFirst Generic Screen|`POST /clinical/prescriptions`|보고서: 의료인 역할·진료·처방·사후관리|
|C18 DUR·처방 서명|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C19 대면·응급 전환|원격 의료인|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 의료인 역할·진료·처방·사후관리|
|C20 진료 종료·사후관리 계획|원격 의료인|ReportFirst Generic Screen|`POST /clinical/encounters/:encounterId/follow-up-plans`|보고서: 의료인 역할·진료·처방·사후관리|
|O01 Clinical Command Center|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O02 원격 사이트 관리|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O03 네트워크·진료실 상태|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O04 의료기기 카탈로그|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O05 의료기기 인벤토리|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O06 교정·점검|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O07 현장 인력 자격|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O08 업무 Capability|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O09 Edge Gateway|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O10 Adapter·Firmware 검증|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O11 외부 시스템|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O12 Interop Queue|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O13 Audit·접근기록|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O14 개인정보·Break Glass|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O15 보안·운영 Incident|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O16 Backup·DR|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O17 Validation·Traceability|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O18 Release Gate|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O19 역할·권한·Scope|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
|O20 서비스 품질·성과|운영·관리|ReportFirst Generic Screen|정적 안내 / 기존 Context / 추가 Read API 필요 시 빈 상태|보고서: 플랫폼 관리·품질·보안|
