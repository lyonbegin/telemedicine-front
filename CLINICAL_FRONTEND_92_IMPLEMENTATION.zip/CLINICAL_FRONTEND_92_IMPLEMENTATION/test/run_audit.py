from pathlib import Path
import json,re,shutil,subprocess,sys,tempfile

ROOT=Path(__file__).resolve().parents[1]

def run_compile():
    fix=Path(tempfile.mkdtemp(prefix="cf92-tsc-"))
    try:
        (fix/"src").mkdir()
        shutil.copytree(ROOT/"src/clinical",fix/"src/clinical")
        (fix/"src/App_socket_videosync.tsx").write_text("""
export function useCollaboration(): any {
  return {
    remoteVideos: [], isSocketConnected: true, joined: false,
    handleJoinRoom: async (_id:string)=>{}, handleManualReconnect: ()=>{},
    localVideoRef: { current: null },
  };
}
""".strip()+"\n")
        (fix/"types.d.ts").write_text(r"""
declare namespace React {
  type ReactNode = any;
  interface Attributes { key?: string | number }
}
declare module 'react' {
  const React: any; export default React;
  export function createContext<T>(value:T): any;
  export function useContext<T=any>(ctx:any): T;
  export function useMemo<T>(factory:()=>T,deps:readonly any[]): T;
  export function useState<T>(initial:T|(()=>T)): [T,(value:T|((prev:T)=>T))=>void];
  export function useEffect(effect:()=>void|(()=>void),deps?:readonly any[]): void;
  export function useRef<T>(initial:T): { current:T };
}
declare module 'react/jsx-runtime' { export const jsx:any; export const jsxs:any; export const Fragment:any; }
declare module 'react-router-dom' {
  export const Navigate:any; export const Route:any; export const Routes:any; export const NavLink:any; export const Outlet:any;
  export function useLocation():any; export function useNavigate():any;
}
declare module 'axios' {
  export interface AxiosInstance {
    interceptors:any;
    get<T=any>(url:string,config?:any):Promise<{data:T}>;
    post<T=any>(url:string,body?:any,config?:any):Promise<{data:T}>;
    put<T=any>(url:string,body?:any):Promise<{data:T}>;
    delete<T=any>(url:string):Promise<{data:T}>;
  }
  export interface AxiosRequestConfig { [key:string]: any }
  const axios:{create(config?:any):AxiosInstance}; export default axios;
}
interface ImportMetaEnv {
  readonly PROD?:boolean; readonly DEV?:boolean; readonly VITE_CLINICAL_DEV_ROLE?:string;
  readonly VITE_API_BASE_URL?:string; readonly VITE_CLINICAL_API_TIMEOUT_MS?:string;
}
interface ImportMeta { readonly env:ImportMetaEnv }
declare namespace JSX { interface IntrinsicAttributes { key?:string|number } interface IntrinsicElements { [elemName:string]:any } }
""".strip()+"\n")
        (fix/"tsconfig.json").write_text(json.dumps({
          "compilerOptions":{"target":"ES2022","module":"ESNext","moduleResolution":"Bundler","jsx":"react-jsx",
          "strict":False,"skipLibCheck":True,"noEmit":True,"lib":["ES2022","DOM","DOM.Iterable"],"allowSyntheticDefaultImports":True},
          "include":["src/**/*.ts","src/**/*.tsx","types.d.ts"]
        }))
        r=subprocess.run(["tsc","-p",str(fix/"tsconfig.json")],capture_output=True,text=True)
        return r
    finally:
        shutil.rmtree(fix,ignore_errors=True)

master=json.loads((ROOT/"evidence/SCREEN_MASTER_92.json").read_text())
screens=master["screens"]
inv=(ROOT/"evidence/BACKEND_API_INVENTORY_238.md").read_text()
backend=set()
for line in inv.splitlines():
    m=re.match(r"- `([A-Z]+) ([^`]+)`",line)
    if m: backend.add(f"{m.group(1)} {m.group(2)}")

map_src=(ROOT/"src/clinical/screenApiMap.generated.ts").read_text()
m=re.search(r"=\s*(\{.*\});",map_src,re.S)
screen_map=json.loads(m.group(1)) if m else {}

bad_map=[{"screen":c,"route":r} for c,rs in screen_map.items() for r in rs if r not in backend]

facade=(ROOT/"src/clinical/api/clinicalFacade.ts").read_text()
def shape(path):return re.sub(r":[A-Za-z_][A-Za-z0-9_]*",":param",path)
backend_shapes={f"{x.split(' ',1)[0]} {shape(x.split(' ',1)[1])}" for x in backend}
bad_facade=[]
for method,url in re.findall(r"api\.(get|post|put|delete)\(`([^`]+)`",facade):
    normalized=re.sub(r"\$\{[^}]+\}",":param",url)
    key=f"{method.upper()} {shape(normalized)}"
    if key not in backend_shapes:bad_facade.append({"key":key,"source":url})

# Installer fixture + idempotency
fixture=Path(tempfile.mkdtemp(prefix="cf92-install-"))
try:
    (fixture/"src/pages").mkdir(parents=True)
    (fixture/"package.json").write_text('{"name":"fixture"}')
    original_index="import { ExcalidrawWrapper } from './App_socket_videosync';\\nexport const Root=()=> <ExcalidrawWrapper><div/></ExcalidrawWrapper>;\\n"
    original_rtc="export const CollaborationContext={};\\nexport const useCollaboration=()=>({});\\nexport const ExcalidrawWrapper=({children}:any)=>children;\\n"
    (fixture/"src/index.tsx").write_text(original_index)
    (fixture/"src/App_socket_videosync.tsx").write_text(original_rtc)
    (fixture/"src/pages/HomePage.tsx").write_text("""import React from 'react';
import { Routes, Route } from 'react-router-dom';
export default function HomePage(){return <Routes><Route path="/" element={<div/>}/></Routes>}
""")
    ins=ROOT/"scripts/install-into-existing-frontend.mjs"
    dry=subprocess.run(["node",str(ins),str(fixture)],capture_output=True,text=True)
    one=subprocess.run(["node",str(ins),str(fixture),"--apply"],capture_output=True,text=True)
    two=subprocess.run(["node",str(ins),str(fixture),"--apply"],capture_output=True,text=True)
    patched=(fixture/"src/pages/HomePage.tsx").read_text()
    installer_checks={
      "dry":dry.returncode==0,"apply":one.returncode==0,"idempotent":two.returncode==0,
      "one_route":patched.count('<Route path="/clinical/*" element={<ClinicalFrontendRoot />} />')==1,
      "one_import":patched.count("import ClinicalFrontendRoot from '../clinical/ClinicalFrontendRoot';")==1,
      "index_unchanged":(fixture/"src/index.tsx").read_text()==original_index,
      "rtc_unchanged":(fixture/"src/App_socket_videosync.tsx").read_text()==original_rtc,
    }
finally:
    shutil.rmtree(fixture,ignore_errors=True)

tsc=run_compile()

all_source="\\n".join(p.read_text(errors="ignore") for p in ROOT.rglob("*") if p.is_file() and p.suffix in {".ts",".tsx",".mjs",".css",".md",".example"})
secret_patterns=[
    r"NEO4J_PASSWORD\s*=",r"BEGIN PRIVATE KEY",r"sk-[A-Za-z0-9]{20,}",
    r"AKIA[0-9A-Z]{16}",r"postgres(?:ql)?://[^\\s]+:[^\\s]+@"
]
secret_hits=[pattern for pattern in secret_patterns if re.search(pattern,all_source)]

registry=(ROOT/"src/clinical/screenRegistry.ts").read_text()
resolver=(ROOT/"src/clinical/screens/ClinicalScreenResolver.tsx").read_text()
generic=(ROOT/"src/clinical/screens/GenericClinicalScreen.tsx").read_text()
rtc=(ROOT/"src/clinical/rtc/ExistingRtcBridge.tsx").read_text()
session=(ROOT/"src/clinical/auth/clinicalSession.ts").read_text()

checks={
 "screens_92":len(screens)==92,
 "codes_unique":len({s["code"] for s in screens})==92,
 "roles_4_26_22_20_20":sum(s["code"].startswith("G") for s in screens)==4 and sum(s["code"].startswith("P") for s in screens)==26 and sum(s["code"].startswith("S") for s in screens)==22 and sum(s["code"].startswith("C") for s in screens)==20 and sum(s["code"].startswith("O") for s in screens)==20,
 "backend_routes_238":len(backend)==238,
 "screen_api_map_valid":not bad_map,
 "facade_route_shapes_valid":not bad_facade,
 "typescript_compile":tsc.returncode==0,
 "installer_dry_apply_idempotent":all(installer_checks.values()),
 "existing_rtc_reused":"useCollaboration" in rtc and "../../App_socket_videosync" in rtc,
 "no_generic_status_patch":"api.patch" not in facade and ".patch(" not in facade,
 "dev_role_disabled_in_production":"!production" in session,
 "generic_screen_no_fake_success":"데이터 대기" in generic,
 "screen_resolver_exists":"ClinicalScreenResolver" in resolver,
 "registry_generated":"CLINICAL_SCREENS" in registry,
 "no_embedded_secrets":not secret_hits,
}
failed=[k for k,v in checks.items() if not v]
result={
 "result":"PASS" if not failed else "FAIL",
 "checksTotal":len(checks),"checksPassed":sum(checks.values()),"failedChecks":failed,
 "checks":checks,"badScreenApiRoutes":bad_map,"badFacadeRoutes":bad_facade,
 "typescript":{"returnCode":tsc.returncode,"stdout":tsc.stdout,"stderr":tsc.stderr},
 "installer":installer_checks,"secretPatternHits":secret_hits,
 "realExistingFrontendNpmBuild":"NOT_RUN_NO_LOCAL_FULL_EXISTING_REPOSITORY"
}
(ROOT/"test/FRONTEND_IMPLEMENTATION_AUDIT.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"result":result["result"],"passed":f"{result['checksPassed']}/{result['checksTotal']}","failed":failed,"tsc":tsc.stdout+tsc.stderr},ensure_ascii=False,indent=2))
if failed:sys.exit(2)
