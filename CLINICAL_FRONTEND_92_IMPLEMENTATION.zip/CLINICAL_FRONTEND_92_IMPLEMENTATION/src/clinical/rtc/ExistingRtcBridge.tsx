import React, { useEffect, useMemo, useRef } from 'react';
import { useCollaboration } from '../../App_socket_videosync';
import { ClinicalBadge, ClinicalButton, ClinicalCard } from '../ui/ClinicalUi';

function RemoteStream({ stream, label }: { stream: MediaStream; label: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (ref.current) {
      ref.current.srcObject = stream;
      ref.current.play().catch(() => undefined);
    }
  }, [stream]);
  return <div className="cf-video-tile"><video ref={ref} autoPlay playsInline /><span>{label}</span></div>;
}

export function ExistingRtcBridge({ visitId }: { visitId?: string }) {
  const rtc = useCollaboration();

  const remote = useMemo(
    () => (rtc.remoteVideos || []).filter((item: any) => item.kind === 'video'),
    [rtc.remoteVideos],
  );

  const join = async () => {
    if (!visitId || rtc.joined) return;
    await rtc.handleJoinRoom(visitId);
  };

  return (
    <ClinicalCard title="실시간 진료">
      <div className="cf-rtc-status">
        <ClinicalBadge tone={rtc.isSocketConnected ? 'success' : 'warning'}>
          {rtc.isSocketConnected ? 'RTC 연결됨' : 'RTC 연결 확인 필요'}
        </ClinicalBadge>
        {visitId && <span>Visit {visitId}</span>}
      </div>

      <div className="cf-video-grid">
        <div className="cf-video-tile cf-video-local">
          <video ref={rtc.localVideoRef} autoPlay muted playsInline />
          <span>내 카메라</span>
        </div>
        {remote.map((item: any) => (
          <RemoteStream
            key={item.consumerId || item.id}
            stream={item.stream}
            label={item.userInfo?.nickname || item.peerId || '원격 참여자'}
          />
        ))}
      </div>

      <div className="cf-action-row">
        {!rtc.joined && visitId && <ClinicalButton onClick={join}>진료 연결</ClinicalButton>}
        {!rtc.isSocketConnected && (
          <ClinicalButton variant="secondary" onClick={rtc.handleManualReconnect}>재연결</ClinicalButton>
        )}
      </div>
    </ClinicalCard>
  );
}
