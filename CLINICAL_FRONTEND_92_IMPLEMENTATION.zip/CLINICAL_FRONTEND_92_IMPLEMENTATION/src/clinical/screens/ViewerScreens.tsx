import React from 'react';
import { WaveformViewer } from '../viewers/WaveformViewer';
import { DicomViewer } from '../viewers/DicomViewer';
import { UltrasoundViewer } from '../viewers/UltrasoundViewer';
import { ClinicalBadge, ClinicalCard } from '../ui/ClinicalUi';

export function ViewerScreen({ kind }: { kind: 'ECG'|'DICOM'|'ULTRASOUND'|'AUSCULTATION'|'LAB' }) {
  if(kind==='ECG')return <WaveformViewer/>;
  if(kind==='DICOM')return <DicomViewer/>;
  if(kind==='ULTRASOUND')return <UltrasoundViewer/>;
  if(kind==='AUSCULTATION')return <WaveformViewer title="디지털 청진"/>;
  return (
    <ClinicalCard title="검사수치 Viewer">
      <table className="cf-table"><thead><tr><th>검사</th><th>결과</th><th>단위</th><th>시각</th></tr></thead>
      <tbody><tr><td>CRP</td><td>3.4</td><td>mg/L</td><td>13:57</td></tr><tr><td>SpO₂</td><td>96</td><td>%</td><td>13:24</td></tr></tbody></table>
      <ClinicalBadge tone="success">출처·시간 확인</ClinicalBadge>
    </ClinicalCard>
  );
}
