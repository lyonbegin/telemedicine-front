# 기존 Frontend Dependency Compatibility

Clinical overlay에서 새로 요구하는 외부 패키지는 없다.

사용:
- react
- react-router-dom
- axios

현재 기존 demo frontend에 이미 있는 dependency만 사용한다.

실시간:
- Clinical 폴더에서 새 mediasoup-client / socket.io-client 인스턴스를 만들지 않는다.
- 기존 `App_socket_videosync.tsx`의 `useCollaboration()`을 재사용한다.

따라서 설치 스크립트는 `package.json`을 수정하지 않는다.
