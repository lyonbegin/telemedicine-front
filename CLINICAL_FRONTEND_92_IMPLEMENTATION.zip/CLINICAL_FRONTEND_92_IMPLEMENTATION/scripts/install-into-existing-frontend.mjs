#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const bundle=path.resolve(here,'..');
const target=path.resolve(process.argv[2] || '.');
const apply=process.argv.includes('--apply');

const source=path.join(bundle,'src','clinical');
const dest=path.join(target,'src','clinical');
const home=path.join(target,'src','pages','HomePage.tsx');
const index=path.join(target,'src','index.tsx');
const rtc=path.join(target,'src','App_socket_videosync.tsx');

const errors=[];
for(const required of [path.join(target,'package.json'),home,index,rtc]){
  if(!fs.existsSync(required))errors.push(`missing ${required}`);
}
if(errors.length){
  console.error(JSON.stringify({result:'FAIL',errors},null,2));
  process.exit(2);
}

const homeText=fs.readFileSync(home,'utf8');
const indexText=fs.readFileSync(index,'utf8');
const checks={
  indexPreservesExcalidrawWrapper:/ExcalidrawWrapper/.test(indexText),
  homeUsesRoutes:/<Routes>/.test(homeText),
  homeUsesRoute:/<Route\s/.test(homeText),
  existingRtcProviderPresent:/useCollaboration|CollaborationContext/.test(fs.readFileSync(rtc,'utf8')),
};
if(Object.values(checks).some(v=>!v)){
  console.error(JSON.stringify({result:'FAIL',checks},null,2));
  process.exit(2);
}

const importLine=`import ClinicalFrontendRoot from '../clinical/ClinicalFrontendRoot';`;
const routeLine=`<Route path="/clinical/*" element={<ClinicalFrontendRoot />} />`;

const patchedImport=homeText.includes(importLine)
  ? homeText
  : homeText.replace(/(import[^;]+;\s*)/, `$1\n${importLine}\n`);

const patched=patchedImport.includes(routeLine)
  ? patchedImport
  : patchedImport.replace('<Routes>', `<Routes>\n            ${routeLine}`);

const report={
  result:apply?'PASS':'DRY_RUN',
  target,
  checks,
  planned:{
    copy:`${source} -> ${dest}`,
    homePagePatch:home,
    route:'/clinical/*',
    indexTsxModified:false,
    existingRtcProviderModified:false,
  }
};

if(!apply){
  console.log(JSON.stringify(report,null,2));
  process.exit(0);
}

fs.mkdirSync(dest,{recursive:true});
fs.cpSync(source,dest,{recursive:true,force:true});
const backup=`${home}.before-clinical-${Date.now()}.bak`;
fs.copyFileSync(home,backup);
fs.writeFileSync(home,patched,'utf8');

console.log(JSON.stringify({...report,backup},null,2));
